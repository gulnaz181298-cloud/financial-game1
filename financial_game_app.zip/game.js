// game.js — simplified but full web-app logic for the classroom game
const cells = [
 "Старт", "Жалақы +5000", "Депозит +10%", "Салық -1500", "Сыйлық +2000", "Кредит +10000",
 "Жалдау -3000", "Инфляция -10%", "Инвестиция +4000", "Потерял кошелек -2000", "Шанс", "Жалақы +5000",
 "Салық -2000", "Банк бонус +3000", "Шанс", "Жалдау -4000", "Инфляция -15%", "Сыйлық +1000",
 "Инвестиция +2000", "Телефон сындырдың -2000", "Шанс", "Жалақы +4000", "Салық -1000", "Кредит -2000/оборот",
 "Сыйлық +1500", "Депозит +5%", "Инфляция -5%", "Инвестиция +3000", "Шанс", "Жалақы +2000",
 "Салық -2500", "Шанс", "Жалдау -3500", "Сыйлық +500", "Инфляция -20%", "Финиш"
];

const chanceCards = [
  {text:"Досыңа қарыз бердің – ол қайтарды (+3000)", effect:(p)=>{p.balance+=3000}},
  {text:"Телефон сындырдың (–2000)", effect:(p)=>{p.balance-=2000}},
  {text:"Инвестиция табысы (келесі айналымда +4000)", effect:(p)=>{p.pending += 4000}},
  {text:"Сабақтан қалдың (жалақыдан айрылдың)", effect:(p)=>{p.balance -= 3000}},
  {text:"Банк бонусы (+2000)", effect:(p)=>{p.balance += 2000}},
  {text:"Сақтандыру төлемі ұтылды (–1500)", effect:(p)=>{p.balance -= 1500}},
  {text:"Жалақы өсімі (+2500)", effect:(p)=>{p.balance += 2500}},
  {text:"Құжаттарды жоғалттың (–1000)", effect:(p)=>{p.balance -= 1000}}
];

let players = [];
let currentPlayerIndex = 0;
let round = 0;
const maxRounds = 10;
const colors = ["#f44336","#4caf50","#ff9800","#2196f3","#9c27b0","#795548"];

// UI refs
const boardEl = document.getElementById('board');
const playersListEl = document.getElementById('playersList');
const logEl = document.getElementById('log');
const diceEl = document.getElementById('dice');
const startBtn = document.getElementById('startBtn');
const rollBtn = document.getElementById('rollBtn');
const addPlayerBtn = document.getElementById('addPlayer');
const playerNameInput = document.getElementById('playerName');
const addDemoBtn = document.getElementById('addDemo');
const loanBtn = document.getElementById('loanBtn');
const nextBtn = document.getElementById('nextBtn');
const currentPlayerEl = document.getElementById('currentPlayer');
const roundEl = document.getElementById('round');
const chanceListEl = document.getElementById('chanceList');

// build board
function buildBoard(){
  boardEl.innerHTML='';
  for(let i=0;i<cells.length;i++){
    const c = document.createElement('div');
    c.className='cell';
    c.dataset.idx = i;
    c.innerHTML = `<div class="title">${cells[i]}</div><div class="small">Клетка ${i+1}</div><div class="tokens"></div>`;
    boardEl.appendChild(c);
  }
}
buildBoard();

// render chance cards
function renderChance(){
  chanceListEl.innerHTML='';
  chanceCards.forEach((c)=>{
    const d = document.createElement('div');
    d.className='chance-card';
    d.innerText = c.text;
    chanceListEl.appendChild(d);
  });
}
renderChance();

// player model
function createPlayer(name,color){
  return {name, color, pos:0, balance:10000, pending:0, loan:0, active:true};
}

function addPlayer(){
  const name = (playerNameInput.value || 'Player').trim();
  if(!name) return;
  if(players.length>=6){ alert('Max 6 players'); return; }
  players.push(createPlayer(name, colors[players.length%colors.length]));
  playerNameInput.value='';
  renderPlayers();
}
addPlayerBtn.addEventListener('click', addPlayer);
addDemoBtn.addEventListener('click', ()=>{
  players = [];
  players.push(createPlayer('Адам', colors[0]));
  players.push(createPlayer('Бота', colors[1]));
  renderPlayers();
  log('Демо-игроктар қосылды.');
});

function renderPlayers(){
  playersListEl.innerHTML='';
  players.forEach((p, idx)=>{
    const el = document.createElement('div');
    el.className='player-row';
    el.innerHTML = `<div style="display:flex;align-items:center"><span class="chip" style="background:${p.color}"></span><strong>${p.name}</strong> ${p.active?'':'(Банкрот)'}</div>
                    <div style="text-align:right"><div>Баланс: <b>${p.balance}</b></div><div>Кредит: <b>${p.loan}</b></div><div>Позиция: <b>${p.pos+1}</b></div></div>`;
    playersListEl.appendChild(el);
  });
  updateTokens();
  updateStatus();
}

function updateTokens(){
  document.querySelectorAll('.cell .tokens').forEach(e=>e.innerHTML='');
  players.forEach((p)=>{
    const cell = document.querySelector(`.cell[data-idx="${p.pos}"] .tokens`);
    if(cell){
      const t = document.createElement('div');
      t.style.width='14px'; t.style.height='14px'; t.style.borderRadius='50%';
      t.style.background = p.color; t.style.border='2px solid white'; t.style.boxShadow='0 1px 0 rgba(0,0,0,0.12)';
      t.title = p.name;
      cell.appendChild(t);
    }
  });
}

function log(text){
  const ts = new Date().toLocaleTimeString();
  logEl.innerHTML = `<div>[${ts}] ${text}</div>` + logEl.innerHTML;
}

// start game
startBtn.addEventListener('click', ()=>{
  if(players.length<2){ alert('Қосу: кемінде 2 ойыншы болу керек.'); return; }
  round = 1; currentPlayerIndex = 0;
  startBtn.disabled = true; rollBtn.disabled = false;
  log('Ойын басталды.');
  renderPlayers();
});

// roll dice
rollBtn.addEventListener('click', ()=>{
  const p = players[currentPlayerIndex];
  if(!p.active){ advanceTurn(); return; }
  const v = Math.floor(Math.random()*6)+1;
  diceEl.innerText = v;
  log(`${p.name} кубик тастады: ${v}`);
  movePlayer(p, v);
  renderPlayers();
  rollBtn.disabled = true;
  nextBtn.disabled = false;
});

loanBtn.addEventListener('click', ()=>{
  const p = players[currentPlayerIndex];
  if(!p) return;
  p.balance += 5000; p.loan += 5000;
  log(`${p.name} несие алды +5000`);
  renderPlayers();
});

nextBtn.addEventListener('click', ()=>{
  advanceTurn();
  rollBtn.disabled = false; nextBtn.disabled = true;
});

function advanceTurn(){
  // apply pending and repay portion of loan
  players.forEach(p=>{
    if(p.pending>0){ p.balance += p.pending; log(`${p.name} алды отложенный доход +${p.pending}`); p.pending=0; }
    if(p.loan>0){
      const repay = Math.min(1000, p.loan, p.balance);
      p.loan -= repay; p.balance -= repay;
      if(repay>0) log(`${p.name} қарыз төледі ${repay}`);
    }
    if(p.balance<=0 && p.active){ p.active=false; log(`${p.name} — банкрот!`); }
  });

  // next player index
  currentPlayerIndex = (currentPlayerIndex+1) % players.length;
  // if wrapped, bump round
  if(currentPlayerIndex===0) round++;
  renderPlayers();
  if(round>maxRounds){ endGame(); return; }
}

function movePlayer(p, steps){
  p.pos = (p.pos + steps) % cells.length;
  log(`${p.name} жылжыды: ${cells[p.pos]} (клетка ${p.pos+1})`);
  applyCell(p);
}

function applyCell(p){
  const c = cells[p.pos];
  if(c.includes('Жалақы')){
    const val = parseInt(c.match(/\+?(\d+)/)[1]);
    p.balance += val; log(`${p.name} жалақы алды +${val}`);
  } else if(c.includes('Депозит')){
    const pct = parseInt(c.match(/\+(\d+)%/)[1]);
    const add = Math.floor(p.balance * pct / 100);
    p.pending += add; log(`${p.name} депозитке салды: +${add} келесі раундта`);
  } else if(c.includes('Салық')){
    const val = parseInt(c.match(/-(\d+)/)[1]);
    p.balance -= val; log(`${p.name} салық төледі -${val}`);
  } else if(c.includes('Сыйлық')){
    const val = parseInt(c.match(/\+(\d+)/)[1]);
    p.balance += val; log(`${p.name} сыйлық алды +${val}`);
  } else if(c.includes('Кредит')){
    if(c.includes('+')){
      const val = parseInt(c.match(/\+(\d+)/)[1]);
      p.balance += val; p.loan += val; log(`${p.name} кредит алды +${val}`);
    } else {
      const pay = Math.min(2000, p.balance);
      p.balance -= pay; p.loan = Math.max(0,p.loan - pay);
      log(`${p.name} кредит төледі ${pay}`);
    }
  } else if(c.includes('Жалдау')){
    const val = parseInt(c.match(/-(\d+)/)[1]);
    p.balance -= val; log(`${p.name} аренда төледі -${val}`);
  } else if(c.includes('Инфляция')){
    const pct = parseInt(c.match(/-(\d+)%/)[1]);
    const loss = Math.floor(p.balance * pct / 100);
    p.balance -= loss; log(`${p.name} инфляциядан жоғалтты -${loss}`);
  } else if(c.includes('Инвестиция')){
    const val = parseInt(c.match(/\+(\d+)/)[1]);
    p.pending += val; log(`${p.name} инвестиция жасады; +${val} келесі раундта`);
  } else if(c.includes('Потерял кошелек')){
    p.balance -= 2000; log(`${p.name} кошелек жоғалтты -2000`);
  } else if(c.includes('Телефон')){
    p.balance -= 2000; log(`${p.name} телефон жөндеді -2000`);
  } else if(c.includes('Шанс')){
    applyChance(p);
  } else if(c.includes('Старт')){
    p.balance += 500; log(`${p.name} старттан өтті +500`);
  }
}

function applyChance(p){
  const idx = Math.floor(Math.random()*chanceCards.length);
  const c = chanceCards[idx];
  c.effect(p);
  log(`${p.name} шанс картасын тартты: ${c.text}`);
  renderPlayers();
}

function endGame(){
  rollBtn.disabled = true; startBtn.disabled = false;
  let winner = players.filter(p=>p.active).sort((a,b)=>b.balance - a.balance)[0];
  log(`Ойын аяқталды. Жеңімпаз: ${winner?winner.name:'—'}`);
  alert(`Ойын аяқталды. Жеңімпаз: ${winner?winner.name:'—'} (Баланс: ${winner?winner.balance:0})`);
}

// initial demo players
players.push(createPlayer('Адам', colors[0]));
players.push(createPlayer('Бота', colors[1]));
renderPlayers();
log('Демо дайын. Қосып бастаңыз.')